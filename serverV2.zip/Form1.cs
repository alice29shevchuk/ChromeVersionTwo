﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ServerChromeV2
{
    public partial class Form1 : Form
    {
        const int PORT = 8008;
        const string HOST = "127.0.0.1";
         static IPAddress ip = IPAddress.Parse(HOST);
        IPEndPoint IPEnd = new IPEndPoint(ip, PORT);
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        Socket client;
        //TcpListener server = new TcpListener(IPAddress.Parse(HOST), PORT);
        public Form1()
        {
            InitializeComponent();
            StartServer();
        }
        public void StartServer()
        {
            try
            {
                socket.Bind(IPEnd);
                socket.Listen(100);
                client = socket.Accept();
                do
                {
                    int byteCount = 0;
                    byte[] mas = new byte[256];
                    StringBuilder stringBuilder = new StringBuilder();
                    do
                    {
                        byteCount = client.Receive(mas);
                        stringBuilder.Append(Encoding.Unicode.GetString(mas, 0, byteCount));
                    } while (client.Available > 0);
                    if(stringBuilder.ToString().Equals("/version/"))
                    {
                        do
                        {
                            byteCount = client.Receive(mas);
                            stringBuilder.Append(Encoding.Unicode.GetString(mas, 0, byteCount));
                        } while (client.Available > 0);
                        File.WriteAllText("VersionNow.txt", stringBuilder.ToString());
                    }
                    if(stringBuilder.ToString().Equals("/file/"))
                    {
                        do
                        {
                            int byteCount2 = 0;
                            byte[] masFile = new byte[256];
                            do
                            {
                                byteCount = client.Receive(masFile);
                            } while (client.Available > 0);
                            File.WriteAllBytes("Copy.txt", masFile);
                        } while (!File.Exists("Copy.txt"));
                        break;
                    }
                    else
                    {
                        this.listBox1.Items.Add(stringBuilder.ToString());
                    }
                }
                while (true);
                   
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            #region
            //try
            //{
            //    server.Start();
            //    do
            //    {
            //        TcpClient client = server.AcceptTcpClient();


            //        NetworkStream stream = client.GetStream();
            //        byte[] buff = new byte[1024];
            //        StringBuilder stringBuilder = new StringBuilder();
            //        do
            //        {
            //            int bytes = stream.Read(buff, 0, buff.Length);
            //            stringBuilder.Append(Encoding.Unicode.GetString(buff, 0, bytes));
            //        } while (stream.DataAvailable);
            //        this.listBox1.Items.Add(stringBuilder.ToString());
            //    } while (true);

            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
            #endregion
        }

        private void button1_Click(object sender, EventArgs e)
        {
            client.Shutdown(SocketShutdown.Both);
            client.Close();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string version = File.ReadAllText("VersionNow.txt");
            MessageBox.Show(version);
        }
    }
}
