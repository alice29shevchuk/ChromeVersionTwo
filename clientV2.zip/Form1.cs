﻿
using Microsoft.AspNetCore.Rewrite.Internal.ApacheModRewrite;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChromeV2
{
    public partial class Form1 : Form
    {
        const int PORT = 8008;
        const string HOST = "127.0.0.1";
        static IPAddress ip = IPAddress.Parse(HOST);
        IPEndPoint IPEnd = new IPEndPoint(ip, PORT);
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        string pathfile = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
        Socket serverSocket = null;
        //TcpClient client = new TcpClient();
        //NetworkStream stream;
        public Form1()
        {
            InitializeComponent();
            StartClient();
        }
        public void StartClient()
        {
            try
            {
                socket.Connect(IPEnd);
                socket.Send(Encoding.Unicode.GetBytes(GetIPAddres()));
                //serverSocket.Accept();
                //byte[] data = Encoding.Unicode.GetBytes("I am client");
                //socket.Send(data);
            }
            catch(Exception ex)
            {

            }
            #region
            //try
            //{
            //    client.Connect(HOST, PORT);
            //    stream =  client.GetStream();
            //    byte[] mas = Encoding.Unicode.GetBytes("hello");
            //    stream.Write(mas, 0, mas.Length);
            //}
            //catch(Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
            #endregion
        }
        public void CloseClient()
        {
            //try
            //{
            //    client.Close();
            //    stream.Close();
            //}
            //catch(Exception ex)
            //{

            //}
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
            }
            catch(Exception ex)
            {

            }
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            object path;
            path = Registry.GetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe", "", null);
            if(path !=null)
            {
                MessageBox.Show(FileVersionInfo.GetVersionInfo(path.ToString()).FileVersion);
            }
            string versionBR = FileVersionInfo.GetVersionInfo(path.ToString()).FileVersion;
            byte[] masVersion = Encoding.Unicode.GetBytes(versionBR);
            socket.Send(Encoding.Unicode.GetBytes("/version/"));
            socket.Send(masVersion);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveHistory();
        }
        public void SaveHistory()
        {
            string historyFile = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\Google\Chrome\User Data\Default\History";
            if (File.Exists(historyFile))
            {
                if (File.Exists(Path.Combine("historyChrome")))
                {
                    File.Delete(Path.Combine("historyChrome"));
                }
                File.Copy(historyFile, Path.Combine("historyChrome"));
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SaveHistory();
            try
            {
                byte[] buff = Encoding.Unicode.GetBytes("/file/");
                socket.Send(buff);
                Thread.Sleep(500);
                buff = null;
                socket.SendFile("historyChrome");
            }
            catch(Exception ex)
            {

            }
            
        }
        public string GetIPAddres()
        {
            return System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName()).AddressList.GetValue(0).ToString();
        }
    }
}
